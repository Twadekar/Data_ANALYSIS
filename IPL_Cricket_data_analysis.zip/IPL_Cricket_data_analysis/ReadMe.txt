IPL ANALYSIS DASHBOARD (Power BI)

PROJECT OVERVIEW
This project is an interactive IPL Analysis Dashboard created using Power BI. It provides insights into player performance, team statistics, and match outcomes across different IPL seasons.

The dashboard helps users analyze batting, bowling, and match-winning trends effectively.

OBJECTIVES

Analyze total runs, wickets, fours, and sixes
Identify top batsmen and bowlers
Track Orange Cap and Purple Cap winners
Analyze team performance and match results
Understand toss impact on match outcomes

KEY METRICS

Total Runs: 22602
Total Wickets: 912
Total Sixes: 681
Total Fours: 8216
Most Player of Match: MEK Hussey

DASHBOARD FEATURES

Tournament Summary
Displays tournament winner (Mumbai Indians)
Shows overall performance metrics
Batting Analysis
Top 5 batsmen based on runs
Batsman stats (runs, strike rate, 4s, 6s)
Orange Cap holder (MEK Hussey – 733 runs)
Bowling Analysis
Top 5 bowlers based on wickets
Bowler stats (wickets, economy, strike rate)
Purple Cap holder (DJ Bravo – 15 wickets)
Team Performance
Top winning teams comparison
Match results (runs vs wickets wins)
Toss Impact
Winning percentage based on toss decision
Comparison between batting first vs fielding
Filters
Year slicer to analyze season-wise data
Player selection filters for detailed stats

TOOLS USED

Power BI (Dashboard creation)
DAX (Measures & calculations)
Dataset (IPL match and player data)

INSIGHTS

MEK Hussey was the top performer in batting
DJ Bravo led in bowling performance
Mumbai Indians emerged as tournament winners
Toss decision has a noticeable impact on match results
Some teams consistently perform better across seasons

HOW TO USE

Open the Power BI (.pbix) file
Select year from the filter
Use slicers to explore player and team data
Analyze visuals for insights